import pygame
import math
import random

from entities.entity import Entity
from game.collision_manager import CollisionManager
from entities.bullet import Bullet


# =============================================================================
#  CONSTANTES DE COMPORTAMIENTO
# =============================================================================

# Distancia máxima desde la base antes de regresar (tipos 1 y 2)
BASE_LEASH_RADIUS   = 300

# Radio de patrulla alrededor de la base
PATROL_RADIUS_MIN   = 80
PATROL_RADIUS_MAX   = 160

# Distancia a la que el tanque "llega" a su waypoint
WAYPOINT_TOLERANCE  = 12

# Distancia de detección del jugador
DETECT_RADIUS       = 200

# Distancia de ataque (disparo)
ATTACK_RADIUS       = 130

# Distancia mínima de flanqueo para tipo 3
FLANK_ORBIT_RADIUS  = 110

# Cooldown de disparo (frames)
SHOOT_COOLDOWN_FRAMES = 60

# Velocidades por tipo
SPEED_BY_TYPE = {1: 1.2, 2: 1.6, 3: 2.0}

# Colores por tipo
COLOR_BY_TYPE = {1: (180, 60, 60), 2: (200, 120, 0), 3: (140, 0, 200)}


# =============================================================================
#  ESTADOS DE LA IA
# =============================================================================

STATE_PATROL  = "PATROL"    # Patrullando alrededor de la base asignada
STATE_CHASE   = "CHASE"     # Persiguiendo al jugador
STATE_ATTACK  = "ATTACK"    # En rango de disparo
STATE_RETURN  = "RETURN"    # Volviendo a la base (leash superado)
STATE_DEFEND  = "DEFEND"    # Cerca de la base, esperando amenaza
STATE_FLANK   = "FLANK"     # Flanqueo (solo tipo 3)
STATE_ASSAULT = "ASSAULT"   # Ataque en masa tras perder base (tipos 1/2)


class EnemyTank(Entity):

    def __init__(self, x, y, size, tank_type=1):
        color = COLOR_BY_TYPE.get(tank_type, (180, 60, 60))
        super().__init__(x, y, size, color)

        self.tank_type   = tank_type
        self.speed       = SPEED_BY_TYPE.get(tank_type, 1.2)
        self.direction   = "DOWN"

        # --- Estado de IA ---
        self.state       = STATE_PATROL

        # --- Base asignada ---
        self.home_base   = None          # Referencia al objetivo/base asignado

        # --- Patrulla ---
        self.patrol_points  = []         # Lista de waypoints circulares
        self.patrol_index   = 0          # Waypoint actual
        self._generate_patrol_points()

        # --- Flanqueo (tipo 3) ---
        self.flank_angle    = random.uniform(0, 2 * math.pi)
        self.flank_dir      = random.choice([-1, 1])  # Sentido de rotación

        # --- Disparo ---
        self.shoot_cooldown = 0

        # --- Modo asalto (tipos 1/2 tras perder su base) ---
        self.base_lost      = False

    # =========================================================================
    #  PATRULLA
    # =========================================================================

    def _generate_patrol_points(self, num_points=6):
        """Genera waypoints en círculo alrededor de la base asignada."""
        self.patrol_points = []
        if self.home_base is None:
            # Sin base: puntos alrededor de la posición actual
            cx, cy = self.rect.centerx, self.rect.centery
        else:
            cx, cy = self.home_base.rect.centerx, self.home_base.rect.centery

        radius = random.randint(PATROL_RADIUS_MIN, PATROL_RADIUS_MAX)
        for i in range(num_points):
            angle = (2 * math.pi / num_points) * i + random.uniform(-0.2, 0.2)
            px = cx + radius * math.cos(angle)
            py = cy + radius * math.sin(angle)
            self.patrol_points.append((px, py))

    def assign_base(self, base):
        """Asigna una base al tanque y regenera los puntos de patrulla."""
        self.home_base = base
        self._generate_patrol_points()

    @property
    def patrol_target(self):
        if not self.patrol_points:
            return None
        return self.patrol_points[self.patrol_index % len(self.patrol_points)]

    def _advance_patrol(self):
        if self.patrol_points:
            self.patrol_index = (self.patrol_index + 1) % len(self.patrol_points)

    # =========================================================================
    #  DISTANCIAS Y GEOMETRÍA
    # =========================================================================

    def distance_to_player(self, player):
        dx = player.rect.centerx - self.rect.centerx
        dy = player.rect.centery - self.rect.centery
        return math.hypot(dx, dy)

    def distance_to_point(self, x, y):
        return math.hypot(x - self.rect.centerx, y - self.rect.centery)

    def distance_to_base(self):
        if self.home_base is None:
            return 0
        return self.distance_to_point(
            self.home_base.rect.centerx,
            self.home_base.rect.centery
        )

    # =========================================================================
    #  MOVIMIENTO
    # =========================================================================

    def _move_toward(self, tx, ty, walls):
        """Mueve el tanque hacia (tx, ty) respetando colisiones."""
        dx = tx - self.rect.centerx
        dy = ty - self.rect.centery
        dist = math.hypot(dx, dy)
        if dist == 0:
            return

        dx /= dist
        dy /= dist

        # Actualizar dirección visual
        if abs(dx) > abs(dy):
            self.direction = "RIGHT" if dx > 0 else "LEFT"
        else:
            self.direction = "DOWN" if dy > 0 else "UP"

        step_x = dx * self.speed
        step_y = dy * self.speed

        # Movimiento horizontal
        self.rect.x += step_x
        if CollisionManager.check_wall_collision(self.rect, walls):
            self.rect.x -= step_x

        # Movimiento vertical
        self.rect.y += step_y
        if CollisionManager.check_wall_collision(self.rect, walls):
            self.rect.y -= step_y

        self.x = self.rect.x
        self.y = self.rect.y

    def _move_flank(self, player, walls):
        """
        Tipo 3: orbita alrededor del jugador en círculo,
        avanzando/retrocediendo para mantenerse en FLANK_ORBIT_RADIUS.
        """
        px, py = player.rect.centerx, player.rect.centery
        dist   = self.distance_to_player(player)

        # Ángulo actual desde el jugador hacia el tanque
        angle_to_tank = math.atan2(
            self.rect.centery - py,
            self.rect.centerx - px
        )

        # Rotar el ángulo para orbitar
        self.flank_angle = angle_to_tank + self.flank_dir * 0.03

        # Posición objetivo en la órbita
        target_x = px + FLANK_ORBIT_RADIUS * math.cos(self.flank_angle)
        target_y = py + FLANK_ORBIT_RADIUS * math.sin(self.flank_angle)

        self._move_toward(target_x, target_y, walls)

    # =========================================================================
    #  DISPARO
    # =========================================================================

    def try_shoot(self):
        """Devuelve una Bullet si puede disparar, None si está en cooldown."""
        if self.shoot_cooldown > 0:
            return None

        self.shoot_cooldown = SHOOT_COOLDOWN_FRAMES
        bullet_size = self.size // 4
        bx = self.rect.centerx - bullet_size // 2
        by = self.rect.centery - bullet_size // 2
        return Bullet(bx, by, bullet_size, self.direction, "ENEMY")

    # =========================================================================
    #  LÓGICA DE ESTADO  (llamada desde AIController)
    # =========================================================================

    def check_base_lost(self):
        """Devuelve True si la base asignada fue destruida."""
        if self.home_base is None:
            return False
        return getattr(self.home_base, "destroyed", False)

    def nearest_base(self, objectives):
        """Devuelve la base activa más cercana al tanque."""
        active = [o for o in objectives if not getattr(o, "destroyed", False)]
        if not active:
            return None
        return min(active, key=lambda o: self.distance_to_point(
            o.rect.centerx, o.rect.centery
        ))

    # =========================================================================
    #  UPDATE PRINCIPAL
    # =========================================================================

    def update(self, player, objectives, walls, ai_state):
        """
        ai_state: dict devuelto por AIController.decide()
          {
            "action":  STATE_*,
            "target":  (x, y) | None
          }
        Devuelve una Bullet o None.
        """
        if self.shoot_cooldown > 0:
            self.shoot_cooldown -= 1

        action = ai_state.get("action", STATE_PATROL)
        target = ai_state.get("target", None)

        bullet = None

        # --- PATROL ---
        if action == STATE_PATROL:
            if self.patrol_target is not None:
                tx, ty = self.patrol_target
                if self.distance_to_point(tx, ty) < WAYPOINT_TOLERANCE:
                    self._advance_patrol()
                else:
                    self._move_toward(tx, ty, walls)

        # --- CHASE ---
        elif action == STATE_CHASE:
            if target:
                self._move_toward(*target, walls)

        # --- ATTACK ---
        elif action == STATE_ATTACK:
            # Se queda quieto y dispara
            bullet = self.try_shoot()

        # --- RETURN ---
        elif action == STATE_RETURN:
            if target:
                self._move_toward(*target, walls)

        # --- DEFEND ---
        elif action == STATE_DEFEND:
            # Patrulla corta alrededor de la base
            if self.patrol_target is not None:
                tx, ty = self.patrol_target
                if self.distance_to_point(tx, ty) < WAYPOINT_TOLERANCE:
                    self._advance_patrol()
                else:
                    self._move_toward(tx, ty, walls)

        # --- FLANK (tipo 3) ---
        elif action == STATE_FLANK:
            self._move_flank(player, walls)
            bullet = self.try_shoot()

        # --- ASSAULT (tipos 1/2 tras perder base) ---
        elif action == STATE_ASSAULT:
            if target:
                self._move_toward(*target, walls)
            dist = self.distance_to_player(player)
            if dist < ATTACK_RADIUS:
                bullet = self.try_shoot()

        return bullet
