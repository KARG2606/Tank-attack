import random
import math


# =============================================================================
#  CONSTANTES (deben coincidir con enemy_tank.py)
# =============================================================================

BASE_LEASH_RADIUS = 300
DETECT_RADIUS     = 200
ATTACK_RADIUS     = 130

STATE_PATROL  = "PATROL"
STATE_CHASE   = "CHASE"
STATE_ATTACK  = "ATTACK"
STATE_RETURN  = "RETURN"
STATE_DEFEND  = "DEFEND"
STATE_FLANK   = "FLANK"
STATE_ASSAULT = "ASSAULT"


class AIController:
    """
    Controlador de IA para tanques enemigos.

    Tipos de tanques:
      1 → Defensor lento. Patrulla su base. Si la pierde, asalta.
      2 → Defensor rápido. Igual que tipo 1 pero más agresivo en radio.
      3 → Atacante. Siempre persigue al jugador y lo flanquea.

    El método `decide` devuelve un dict:
        { "action": STATE_*, "target": (x, y) | None }

    La asignación inicial de bases se hace llamando a
        `AIController.assign_bases(enemies, objectives)`
    desde el game manager al crear la oleada.
    """

    def __init__(self, prolog_manager):
        self.prolog = prolog_manager

    # =========================================================================
    #  ASIGNACIÓN DE BASES  (llamar una vez al spawnear los tanques)
    # =========================================================================

    @staticmethod
    def assign_bases(enemies, objectives):
        """
        Asigna a cada tanque tipo 1 y 2 la base activa más cercana.
        Los tanques tipo 3 no reciben base asignada.
        """
        active_bases = [o for o in objectives
                        if not getattr(o, "destroyed", False)]
        if not active_bases:
            return

        for enemy in enemies:
            if enemy.tank_type == 3:
                continue  # Tipo 3 no defiende bases

            if enemy.home_base is not None:
                # Ya tiene base asignada: comprobar si sigue activa
                if not getattr(enemy.home_base, "destroyed", False):
                    continue

            # Asignar la base activa más cercana
            nearest = min(
                active_bases,
                key=lambda o: math.hypot(
                    o.rect.centerx - enemy.rect.centerx,
                    o.rect.centery - enemy.rect.centery
                )
            )
            enemy.assign_base(nearest)

    # =========================================================================
    #  CONSULTA A PROLOG
    # =========================================================================

    def _query_prolog(self, enemy, player, distance):
        """
        Consulta al motor Prolog para validar/refinar la decisión.
        Se espera que prolog_manager exponga un método `query(fact)`.

        Hechos que se pueden consultar (adapta según tu base de conocimiento):
          - enemy_type(Type)
          - distance_to_player(Distance)
          - base_destroyed(BaseId)
          - should_attack / should_patrol / should_flank / should_retreat
        """
        try:
            # Insertar hechos dinámicos para la consulta
            self.prolog.assertz(f"tank_type({enemy.tank_type})")
            self.prolog.assertz(f"distance_to_player({int(distance)})")

            base_id = id(enemy.home_base) if enemy.home_base else 0
            base_destroyed = (
                1 if getattr(enemy.home_base, "destroyed", False) else 0
            )
            self.prolog.assertz(f"base_destroyed({base_id}, {base_destroyed})")

            # Consultar la acción recomendada por Prolog
            result = list(self.prolog.query("recommended_action(Action)"))

            # Limpiar hechos temporales
            self.prolog.retract(f"tank_type({enemy.tank_type})")
            self.prolog.retract(f"distance_to_player({int(distance)})")
            self.prolog.retract(f"base_destroyed({base_id}, {base_destroyed})")

            if result:
                return result[0].get("Action", None)
        except Exception:
            # Si Prolog falla, continuar con lógica Python
            pass

        return None  # None → usar lógica Python pura

    # =========================================================================
    #  LÓGICA TIPO 3  (atacante/flanqueador)
    # =========================================================================

    def _decide_type3(self, enemy, player, distance):
        """
        Tipo 3: siempre ataca al jugador.
        - Si está en rango de disparo → FLANK (orbita y dispara)
        - Si está lejos → CHASE
        """
        if distance < ATTACK_RADIUS:
            return {
                "action": STATE_FLANK,
                "target": (player.rect.centerx, player.rect.centery)
            }

        return {
            "action": STATE_CHASE,
            "target": (player.rect.centerx, player.rect.centery)
        }

    # =========================================================================
    #  LÓGICA TIPOS 1 y 2  (defensores)
    # =========================================================================

    def _decide_defender(self, enemy, player, distance):
        """
        Tipos 1 y 2: defienden su base.
        Prioridades:
          1. Si la base fue destruida → ASSAULT (unirse al ataque)
          2. Si el jugador está en rango de ataque → ATTACK
          3. Si el jugador está detectado y el tanque no se ha alejado demasiado
             de su base → CHASE
          4. Si el tanque se alejó demasiado de la base → RETURN
          5. Si el jugador está cerca de la base (radio de defensa) → DEFEND
          6. Patrulla normal → PATROL
        """
        # 1. Base destruida → modo asalto
        if getattr(enemy.home_base, "destroyed", False):
            enemy.base_lost = True

        if enemy.base_lost:
            return {
                "action": STATE_ASSAULT,
                "target": (player.rect.centerx, player.rect.centery)
            }

        # 2. Ataque directo si está muy cerca
        if distance < ATTACK_RADIUS:
            return {
                "action": STATE_ATTACK,
                "target": (player.rect.centerx, player.rect.centery)
            }

        dist_to_base = enemy.distance_to_base()

        # 3. Perseguir si el jugador está detectado Y dentro del leash
        if distance < DETECT_RADIUS and dist_to_base < BASE_LEASH_RADIUS:
            return {
                "action": STATE_CHASE,
                "target": (player.rect.centerx, player.rect.centery)
            }

        # 4. Leash superado → regresar a la base
        if dist_to_base > BASE_LEASH_RADIUS:
            if enemy.home_base:
                bx = enemy.home_base.rect.centerx
                by = enemy.home_base.rect.centery
            else:
                bx, by = enemy.rect.centerx, enemy.rect.centery
            return {
                "action": STATE_RETURN,
                "target": (bx, by)
            }

        # 5. Jugador cerca de la base pero fuera del leash del tanque → DEFEND
        if enemy.home_base:
            dist_player_to_base = math.hypot(
                player.rect.centerx - enemy.home_base.rect.centerx,
                player.rect.centery - enemy.home_base.rect.centery
            )
            if dist_player_to_base < BASE_LEASH_RADIUS:
                return {
                    "action": STATE_DEFEND,
                    "target": (
                        enemy.home_base.rect.centerx,
                        enemy.home_base.rect.centery
                    )
                }

        # 6. Patrulla normal
        patrol_target = enemy.patrol_target
        return {
            "action": STATE_PATROL,
            "target": patrol_target
        }

    # =========================================================================
    #  PUNTO DE ENTRADA PRINCIPAL
    # =========================================================================

    def decide(self, enemy, player, objectives, walls):
        """
        Decide la acción del tanque para este frame.

        Parámetros:
            enemy      : EnemyTank
            player     : PlayerTank
            objectives : lista de bases/objetivos del mapa
            walls      : lista de paredes

        Retorna:
            dict { "action": STATE_*, "target": (x, y) | None }
        """
        distance = enemy.distance_to_player(player)

        # --- Consulta opcional a Prolog ---
        prolog_action = self._query_prolog(enemy, player, distance)
        # Si Prolog devuelve una acción conocida, respetarla directamente
        if prolog_action in (
            STATE_PATROL, STATE_CHASE, STATE_ATTACK,
            STATE_RETURN, STATE_DEFEND, STATE_FLANK, STATE_ASSAULT
        ):
            return {
                "action": prolog_action,
                "target": (player.rect.centerx, player.rect.centery)
            }

        # --- Lógica Python ---
        if enemy.tank_type == 3:
            return self._decide_type3(enemy, player, distance)

        # Tipos 1 y 2
        # Asegurar que tienen base asignada (por si acaso)
        if enemy.home_base is None or getattr(enemy.home_base, "destroyed", False):
            new_base = enemy.nearest_base(objectives)
            if new_base:
                enemy.assign_base(new_base)

        return self._decide_defender(enemy, player, distance)
